﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CodeFirstExistingDatabaseSample
{
    public class Comodo
    {
        public int IdComodo { get; set; }
        public string DescricaoComodo { get; set; }
    }
}
