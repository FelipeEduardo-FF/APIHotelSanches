﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CodeFirstExistingDatabaseSample
{
    public class ComodoDeQuarto
    {
        public int IdComodo { get; set; }
        public int IdTipoQuarto { get; set; }
        public int Quantidade { get; set; }
    }
}
