﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CodeFirstExistingDatabaseSample
{
    public  class ItemFrigobar
    {
        public int IdFrigobar { get; set; }
        public int IdProduto { get; set; }
        public int Quantidade { get; set; }
    }
}
